"""
Telegram Bot — Upload Approval Workflow

Workflow:
1. Videos landen in output/ (von Render-Pipeline)
2. Bot schickt alle Videos per Telegram zur Prüfung
3. Du gibst einzeln oder alle frei
4. Freigegebene Videos → approved/ Ordner
5. meta_uploader.py lädt sie sequenziell hoch

Safety: Alles PAUSED auf Meta — du aktivierst manuell.
"""

import os
import json
import asyncio
import logging
from pathlib import Path
from datetime import datetime
from dotenv import load_dotenv

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

from meta_uploader import run_upload_batch, get_uploads_today, MAX_UPLOADS_PER_DAY

load_dotenv()

logger = logging.getLogger(__name__)

# ─── Config ───────────────────────────────────────────────────────────────────
BOT_TOKEN   = os.getenv("TELEGRAM_BOT_TOKEN", "")
CHAT_ID     = int(os.getenv("TELEGRAM_CHAT_ID", "0"))

OUTPUT_DIR  = Path(os.getenv("OUTPUT_DIR",   "output"))     # Von Render-Pipeline
APPROVED_DIR = Path(os.getenv("APPROVED_DIR", "approved"))  # Für Uploader
SKIPPED_DIR  = Path(os.getenv("SKIPPED_DIR",  "skipped"))

PENDING_FILE   = Path("logs/pending_approval.json")
DECISIONS_FILE = Path("logs/approval_decisions.json")


# ─── State ────────────────────────────────────────────────────────────────────

def load_pending() -> dict:
    if PENDING_FILE.exists():
        return json.loads(PENDING_FILE.read_text(encoding="utf-8"))
    return {"batch": [], "decisions": {}, "batch_id": None}


def save_pending(data: dict):
    PENDING_FILE.parent.mkdir(exist_ok=True)
    PENDING_FILE.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def log_decision(filename: str, decision: str, note: str = ""):
    log = []
    if DECISIONS_FILE.exists():
        log = json.loads(DECISIONS_FILE.read_text(encoding="utf-8"))
    log.append({
        "timestamp": datetime.now().isoformat(),
        "filename":  filename,
        "decision":  decision,
        "note":      note,
    })
    DECISIONS_FILE.write_text(json.dumps(log, indent=2, ensure_ascii=False), encoding="utf-8")


# ─── Hilfsfunktionen ─────────────────────────────────────────────────────────

async def send_safe(context: ContextTypes.DEFAULT_TYPE, text: str, **kwargs):
    """Telegram-Nachricht mit Fehlerbehandlung."""
    try:
        return await context.bot.send_message(chat_id=CHAT_ID, text=text, **kwargs)
    except Exception as e:
        logger.error(f"Telegram-Fehler beim Senden: {e}")


def get_output_videos() -> list:
    OUTPUT_DIR.mkdir(exist_ok=True)
    return sorted(OUTPUT_DIR.glob("*.mp4")) + sorted(OUTPUT_DIR.glob("*.MP4"))


def get_decision_keyboard(filename: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("✅ Freigeben",  callback_data=f"approve|{filename}"),
            InlineKeyboardButton("❌ Überspringen", callback_data=f"skip|{filename}"),
        ]
    ])


def get_batch_keyboard(batch_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("✅ Alle freigeben",    callback_data=f"approve_all|{batch_id}"),
            InlineKeyboardButton("📋 Einzeln prüfen",   callback_data=f"review_single|{batch_id}"),
        ],
        [
            InlineKeyboardButton("📤 Freigegeben jetzt hochladen", callback_data=f"upload_now|{batch_id}"),
        ]
    ])


# ─── Command Handler ──────────────────────────────────────────────────────────

async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🍷 *Meta Upload Bot — Weingut Huppert*\n\n"
        "Befehle:\n"
        "/prüfen — Videos im output/ Ordner anzeigen und freigeben\n"
        "/status — Heutiger Upload-Stand\n"
        "/queue — Warteschlange anzeigen\n"
        "/hochladen — Freigegebene Videos jetzt hochladen\n"
        "/hilfe — Diese Nachricht",
        parse_mode="Markdown"
    )


async def cmd_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uploads_today = get_uploads_today()
    remaining     = MAX_UPLOADS_PER_DAY - uploads_today
    videos_ready  = len(get_output_videos())
    pending       = load_pending()
    approved_count = sum(1 for v in pending.get("decisions", {}).values() if v == "approve")

    text = (
        f"📊 *Upload-Status*\n\n"
        f"Heute hochgeladen: {uploads_today}/{MAX_UPLOADS_PER_DAY}\n"
        f"Noch möglich heute: {remaining}\n"
        f"Videos im output/ Ordner: {videos_ready}\n"
        f"Freigegeben (noch nicht hochgeladen): {approved_count}"
    )
    await update.message.reply_text(text, parse_mode="Markdown")


async def cmd_pruefen(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Schickt alle Videos aus output/ zur Prüfung."""
    videos = get_output_videos()

    if not videos:
        await update.message.reply_text(
            "📂 Keine Videos im output/ Ordner.\n\n"
            "Sobald die Render-Pipeline fertig ist, landen die Videos dort."
        )
        return

    batch_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    batch    = [v.name for v in videos]

    pending = {
        "batch":     batch,
        "decisions": {},
        "batch_id":  batch_id,
        "created":   datetime.now().isoformat(),
    }
    save_pending(pending)

    await send_safe(
        context,
        f"🎬 *{len(videos)} Video(s) bereit zur Freigabe*\n\n"
        f"Ich schicke sie jetzt einzeln. Prüfe jeden Clip und entscheide:\n"
        f"✅ Freigeben = wird hochgeladen\n"
        f"❌ Überspringen = wird nicht hochgeladen\n\n"
        f"Oder unten alle auf einmal freigeben:",
        parse_mode="Markdown",
        reply_markup=get_batch_keyboard(batch_id),
    )

    # Videos einzeln schicken ohne auf Antwort zu warten
    for video_path in videos:
        try:
            with open(video_path, "rb") as f:
                await context.bot.send_video(
                    chat_id=CHAT_ID,
                    video=f,
                    caption=f"📹 {video_path.name}",
                    reply_markup=get_decision_keyboard(video_path.name),
                    supports_streaming=True,
                )
            # Kleiner Delay zwischen Video-Sends (Telegram-Rate-Limit)
            await asyncio.sleep(1.5)
        except Exception as e:
            logger.error(f"Fehler beim Senden von {video_path.name}: {e}")
            await send_safe(context, f"⚠️ Konnte {video_path.name} nicht senden: {e}")


async def cmd_hochladen(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Startet Upload der freigegebenen Videos."""
    pending = load_pending()
    approved = [
        name for name, dec in pending.get("decisions", {}).items()
        if dec == "approve"
    ]

    if not approved:
        await update.message.reply_text(
            "📋 Keine freigegebenen Videos.\n"
            "Nutze /prüfen um Videos freizugeben."
        )
        return

    uploads_today = get_uploads_today()
    remaining     = MAX_UPLOADS_PER_DAY - uploads_today

    if remaining <= 0:
        await update.message.reply_text(
            f"🛑 Tages-Limit erreicht ({MAX_UPLOADS_PER_DAY}/{MAX_UPLOADS_PER_DAY}).\n"
            f"Videos sind in der Queue für morgen gespeichert."
        )
        return

    to_upload = approved[:remaining]
    queued    = approved[remaining:]

    msg = (
        f"📤 *Upload startet*\n\n"
        f"Hochladen: {len(to_upload)} Video(s)\n"
        f"Noch möglich heute: {remaining}\n"
    )
    if queued:
        msg += f"In Queue für morgen: {len(queued)}\n"

    msg += "\nDelay zwischen Uploads: 2–3 Minuten (Account-Schutz)"

    await update.message.reply_text(msg, parse_mode="Markdown")

    # Videos in approved/ verschieben
    APPROVED_DIR.mkdir(exist_ok=True)
    video_paths = []
    for name in to_upload:
        src = OUTPUT_DIR / name
        if src.exists():
            dest = APPROVED_DIR / name
            src.rename(dest)
            video_paths.append(dest)

    # Upload im Hintergrund starten
    asyncio.create_task(
        run_upload_async(context, video_paths, queued)
    )


async def run_upload_async(context, video_paths: list, queued_names: list):
    """Upload läuft asynchron — Bot bleibt dabei reaktionsfähig."""
    await send_safe(context, f"⏳ Upload läuft... ({len(video_paths)} Videos)")

    try:
        results, leftover = run_upload_batch(video_paths)
        success = sum(1 for r in results if r["status"] == "success")
        failed  = sum(1 for r in results if r["status"] == "error")

        summary = (
            f"✅ *Upload abgeschlossen*\n\n"
            f"Hochgeladen: {success}\n"
            f"Fehler: {failed}\n"
        )
        if queued_names or leftover:
            total_queued = len(queued_names) + len(leftover)
            summary += f"In Queue für morgen: {total_queued}\n"

        summary += "\n⚠️ Alle Ads sind auf Meta *PAUSED* — bitte im Ads Manager prüfen und aktivieren."

        await send_safe(context, summary, parse_mode="Markdown")

    except Exception as e:
        await send_safe(context, f"❌ Upload-Fehler: {e}")


async def cmd_queue(update: Update, context: ContextTypes.DEFAULT_TYPE):
    from meta_uploader import load_queue
    queue = [q for q in load_queue() if q["status"] == "pending"]
    if not queue:
        await update.message.reply_text("📋 Queue ist leer.")
        return

    lines = [f"📋 *{len(queue)} Video(s) in Queue:*\n"]
    for q in queue[:20]:
        name  = Path(q["path"]).name
        added = q["added"][:10]
        lines.append(f"• {name} (hinzugefügt: {added})")

    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


# ─── Callback Handler (Buttons) ──────────────────────────────────────────────

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    data    = query.data
    action, payload = data.split("|", 1)
    pending = load_pending()

    if action == "approve":
        filename = payload
        pending["decisions"][filename] = "approve"
        save_pending(pending)
        log_decision(filename, "approve")

        approved_count = sum(1 for v in pending["decisions"].values() if v == "approve")
        total          = len(pending["batch"])

        await query.edit_message_caption(
            f"✅ {filename} — freigegeben\n({approved_count}/{total} entschieden)",
            reply_markup=None,
        )

    elif action == "skip":
        filename = payload
        pending["decisions"][filename] = "skip"
        save_pending(pending)
        log_decision(filename, "skip")

        # In skipped/ verschieben
        SKIPPED_DIR.mkdir(exist_ok=True)
        src = OUTPUT_DIR / filename
        if src.exists():
            src.rename(SKIPPED_DIR / filename)

        await query.edit_message_caption(
            f"❌ {filename} — übersprungen",
            reply_markup=None,
        )

        # Alle entschieden?
        await check_all_decided(context, pending)

    elif action == "approve_all":
        videos = pending.get("batch", [])
        for name in videos:
            if name not in pending["decisions"]:
                pending["decisions"][name] = "approve"
                log_decision(name, "approve", "bulk_approve")
        save_pending(pending)

        count = sum(1 for v in pending["decisions"].values() if v == "approve")
        await query.edit_message_text(
            f"✅ Alle {count} Videos freigegeben!\n\n"
            f"Nutze /hochladen um den Upload zu starten.",
        )

    elif action == "review_single":
        await query.edit_message_text(
            "📋 Prüfe die Videos oben einzeln mit ✅/❌\n\n"
            "Wenn fertig: /hochladen"
        )

    elif action == "upload_now":
        # Direkt aus dem Button hochladen
        await query.edit_message_text("📤 Upload wird gestartet...")
        # cmd_hochladen-Logik hier inline
        approved = [
            name for name, dec in pending.get("decisions", {}).items()
            if dec == "approve"
        ]
        if not approved:
            await send_safe(context, "Noch keine Videos freigegeben. Nutze ✅ bei den Videos oben.")
            return

        APPROVED_DIR.mkdir(exist_ok=True)
        video_paths = []
        for name in approved:
            src = OUTPUT_DIR / name
            if src.exists():
                dest = APPROVED_DIR / name
                src.rename(dest)
                video_paths.append(dest)

        asyncio.create_task(run_upload_async(context, video_paths, []))


async def check_all_decided(context, pending: dict):
    """Sendet Zusammenfassung wenn alle Videos entschieden wurden."""
    total    = len(pending["batch"])
    decided  = len(pending["decisions"])
    if decided < total:
        return

    approved = sum(1 for v in pending["decisions"].values() if v == "approve")
    skipped  = sum(1 for v in pending["decisions"].values() if v == "skip")

    await send_safe(
        context,
        f"📊 *Alle {total} Videos geprüft*\n\n"
        f"✅ Freigegeben: {approved}\n"
        f"❌ Übersprungen: {skipped}\n\n"
        f"Nutze /hochladen um die {approved} freigegebenen Videos hochzuladen.",
        parse_mode="Markdown",
    )


# ─── Main ─────────────────────────────────────────────────────────────────────

def main():
    if not BOT_TOKEN:
        raise ValueError("TELEGRAM_BOT_TOKEN fehlt in .env")
    if not CHAT_ID:
        raise ValueError("TELEGRAM_CHAT_ID fehlt in .env")

    app = Application.builder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start",      cmd_start))
    app.add_handler(CommandHandler("hilfe",      cmd_start))
    app.add_handler(CommandHandler("prüfen",     cmd_pruefen))
    app.add_handler(CommandHandler("prufen",     cmd_pruefen))   # Ohne Umlaut
    app.add_handler(CommandHandler("status",     cmd_status))
    app.add_handler(CommandHandler("hochladen",  cmd_hochladen))
    app.add_handler(CommandHandler("queue",      cmd_queue))
    app.add_handler(CallbackQueryHandler(handle_callback))

    logger.info("🤖 Telegram Upload-Bot gestartet")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
